package com.petpeers.controller;

import java.util.List;

import org.hibernate.annotations.Proxy;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.petpeers.model.Pet;
import com.petpeers.model.User;
import com.petpeers.service.PetService;
import com.petpeers.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private PetService petservices;

	@PostMapping(value = "/add")
	public ResponseEntity<User> create(@RequestBody User user) {
		return new ResponseEntity<>(userService.addUser(user), HttpStatus.OK);

	}

	@GetMapping(value = "read/{var}")
	public ResponseEntity<User> readOne(@PathVariable("var") Long abc) {
		return new ResponseEntity<User>(userService.getUserById(abc), HttpStatus.OK);
	}

//	@GetMapping(value = "/find")
//	public ResponseEntity<User> readTwo(@PathVariable("var") String abc) {
//	return new ResponseEntity<User>(userService.findByUserName(abc), HttpStatus.OK);
//
//	 }

	@GetMapping(value = "/readallusers")
	public ResponseEntity<List<User>> readAll() {
		return new ResponseEntity<List<User>>(userService.getAllUser(), HttpStatus.OK);

	}

	@DeleteMapping(value = "/delete")
	public ResponseEntity<Long> deleteOne(@PathVariable("var") Long abc) {
		return new ResponseEntity<Long>(userService.deleteUserById(abc), HttpStatus.OK);
	}

	@PutMapping(value = "/updateuser")
	public ResponseEntity<User> update(@RequestBody User user) {
		return new ResponseEntity<User>(userService.updateUser(user), HttpStatus.OK);
	}

	@GetMapping(value = "/mypet/{id}")
	public ResponseEntity<List<Pet>> getMyPet(@PathVariable("id") Long id) {
		return new ResponseEntity<List<Pet>>(petservices
				.getMyPet(id), HttpStatus.OK);
	}

}
