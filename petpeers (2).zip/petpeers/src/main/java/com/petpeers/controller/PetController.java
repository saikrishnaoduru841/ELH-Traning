package com.petpeers.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.petpeers.model.Pet;
import com.petpeers.service.PetService;

@RestController
@RequestMapping("/pet")
public class PetController {

	@Autowired
	private PetService petService;
	
	
	@PostMapping(value="/addPet")
	public ResponseEntity<String> save(@RequestBody Pet pet){
		 petService.savePets(pet);
		 return new ResponseEntity<String>("Pet Added Successfully" ,HttpStatus.OK);
	}
	
	@GetMapping("/getPet")
    public ResponseEntity<Set<Pet>> fetchData() {
        Set<Pet> list = petService.getAllPets();
        if (list.size() == 0) {
            return new ResponseEntity<Set<Pet>>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<Set<Pet>>(list, HttpStatus.OK);
    }
	
}
