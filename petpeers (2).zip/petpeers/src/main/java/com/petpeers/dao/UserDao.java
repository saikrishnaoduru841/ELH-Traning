package com.petpeers.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.petpeers.model.Pet;
import com.petpeers.model.User;
@Repository
public interface UserDao extends JpaRepository<User, Long> {

	//public abstract List<Pet> buypets();

//	public abstract User findByUserName(String name);


//	public abstract List<Pet> getMyPets();



	

	

}
