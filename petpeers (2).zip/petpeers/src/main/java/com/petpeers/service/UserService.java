package com.petpeers.service;

import java.util.List;

import org.springframework.http.HttpStatus;

import com.petpeers.model.Pet;
import com.petpeers.model.User;

public interface UserService {
	
	
	public abstract User addUser(User user);
	public abstract User updateUser(User user);
	public abstract List<User> getAllUser();
	public abstract User getUserById(Long id);
	public abstract Long deleteUserById(Long id);
	//public abstract User findByUserName(String name);
	//public abstract List<Pet>buyPet(long petId, User user);
	//public abstract List<Pet>getMyPet(long petId);
	
	
	
	
}
