package com.petpeers.service;

import java.util.List;
import java.util.Set;

import com.petpeers.model.Pet;

public interface PetService {

	
	public abstract Pet savePets(Pet pet);
	public abstract Set<Pet> getAllPets();
	public abstract List<Pet>getMyPet(Long petId);
	
	
}