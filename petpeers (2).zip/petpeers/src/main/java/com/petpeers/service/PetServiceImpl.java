package com.petpeers.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.petpeers.dao.PetDao;
import com.petpeers.model.Pet;
import com.petpeers.model.User;

@Service
public class PetServiceImpl implements PetService {

	@Autowired
	private PetDao petDao;

	@Override
	public Pet savePets(Pet pet) {
		return petDao.save(pet);
	}

	@Override
	public Set<Pet> getAllPets() {
		Pet petEntity = new Pet();
		Set<Pet> response=new HashSet<Pet>();
		List<Pet> petList = petDao.findAll();
		for (Pet pet : petList) {
			petEntity.setPetId(pet.getPetId());
			petEntity.setPetAge(pet.getPetAge());
			petEntity.setPetName(pet.getPetName());
			petEntity.setPetPlace(pet.getPetPlace());
			response.add(petEntity);
		}
		return response;
	}

	@Override
	public List<Pet> getMyPet(Long id) {
		Pet tempPet = new Pet();
		List<Pet> pets = new ArrayList<Pet>();
		Set<Pet> petSet = getAllPets();
		if (petSet != null && id > 0) {
			for (Pet pet : petSet) {
				if (pet.getOwner().getId() == id) {
					tempPet = pet;
					pets.add(tempPet);
				}
			}
		}
		return pets;
	}

}
