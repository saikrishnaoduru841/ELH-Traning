package com.petpeers.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.petpeers.dao.UserDao;
import com.petpeers.model.Pet;
import com.petpeers.model.User;
@Service
public class UserServiceImpl implements  UserService {
	
	@Autowired
	private UserDao userDao;

	@Override
	public User addUser(User user) {
		return  userDao.save(user);
		
	}

	@Override
	public User updateUser(User user) {
		return userDao.save(user);
	}

	@Override
	public List<User> getAllUser() {
		List<User> response = new ArrayList<User>();
		User userEntity = new User();
		List<User> userList = userDao.findAll();
		for (User user : userList) {
			userEntity.setId(user.getId());
			userEntity.setUserName(user.getUserName());
			userEntity.setUserPassword(user.getUserPassword());
			response.add(userEntity);
		}
		return response;
	}

	@Override
	public User getUserById(Long id) {
		User temp=null;
		Optional<User> var=userDao.findById(id);
		if(var.isPresent()) {
			temp=var.get();
		}
		return temp;
	}
	
	

	@Override
	public Long deleteUserById(Long id) {
		userDao.deleteById(id);
		return id;
	}

//	@Override
//	public List<Pet> buyPet(long petId) {
//		return userDao.buypets();
//	}

	/*
	 * @Override public List<Pet> getMyPet(long petId) { PetServiceImpl
	 * petservices=new PetServiceImpl(); List<Pet>
	 * petList=petservices.getMyPets(petId); return petList; }
	 */

//	@Override
//	public List<Pet> getMyPet(Pet pet) {
//		return userDao.getMyPets();
//	}

//	@Override
//	public User findByUserName(String name) {
//		return userDao.findByUserName(name);
//	}
//



}