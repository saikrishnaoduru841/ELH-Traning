package com.petpeers.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="pet_user")
public class User implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String  userName;
	private String  userPassword;
	
	@OneToMany(mappedBy="owner",cascade=CascadeType.ALL,orphanRemoval = true)
	private Set<Pet> pets;
	
	public User() {
		super();
	}

	

	public User(Long id, String userName, String userPassword, Set<Pet> pets) {
		super();
		this.id = id;
		this.userName = userName;
		this.userPassword = userPassword;
		this.pets = pets;
	}



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public Set getPets() {
		return pets;
	}

	public void setPets(Set pets) {
		this.pets = pets;
	}



	@Override
	public String toString() {
		return "User [id=" + id + ", userName=" + userName + ", userPassword=" + userPassword + ", pets=" + pets + "]";
	}

	
	
	
	
	
	
	
	
	
}


