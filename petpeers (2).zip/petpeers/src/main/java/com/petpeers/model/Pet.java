package com.petpeers.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="pets")
public class Pet implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long petId;
	private String  petName;
	private int  petAge;
	private String  petPlace;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="pet_ownerid")
	private User owner;

	public Pet() {
		super();
	}

	public Pet(long petId, String petName, int petAge, String petPlace, User owner) {
		super();
		this.petId = petId;
		this.petName = petName;
		this.petAge = petAge;
		this.petPlace = petPlace;
		this.owner = owner;
	}
	
	

	public long getPetId() {
		return petId;
	}

	public void setPetId(long petId) {
		this.petId = petId;
	}

	public String getPetName() {
		return petName;
	}

	public void setPetName(String petName) {
		this.petName = petName;
	}

	public int getPetAge() {
		return petAge;
	}

	public void setPetAge(int petAge) {
		this.petAge = petAge;
	}

	public String getPetPlace() {
		return petPlace;
	}

	public void setPetPlace(String petPlace) {
		this.petPlace = petPlace;
	}

	public User getOwner() {
		return owner;
	}

	

	public void setOwner(User owner) {
		this.owner = owner;
	}

	@Override
	public String toString() {
		return "Pet [petId=" + petId + ", petName=" + petName + ", petAge=" + petAge + ", petPlace=" + petPlace
				+ ", owner=" + owner + "]";
	}

	
}