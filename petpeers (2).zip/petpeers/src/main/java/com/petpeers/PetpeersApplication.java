package com.petpeers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages ="com.petpeers")
public class PetpeersApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetpeersApplication.class, args);
	}

}
